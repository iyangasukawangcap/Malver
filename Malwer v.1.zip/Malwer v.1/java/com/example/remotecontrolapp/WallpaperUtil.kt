object WallpaperUtil {
    fun setWallpaper(context: Context, imageResId: Int) {
        val wallpaperManager = WallpaperManager.getInstance(context)
        val bitmap = BitmapFactory.decodeResource(context.resources, imageResId)
        wallpaperManager.setBitmap(bitmap)
    }
}
