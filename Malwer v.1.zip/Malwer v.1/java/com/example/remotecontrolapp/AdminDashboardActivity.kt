package com.example.remotecontrolapp

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase

class AdminDashboardActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_dashboard)

        val btnLockUser = findViewById<Button>(R.id.btnLockUser)
        btnLockUser.setOnClickListener {
            val db = FirebaseDatabase.getInstance().reference
            db.child("commands").child("lock").setValue(true)
            Toast.makeText(this, "Perintah kunci dikirim", Toast.LENGTH_SHORT).show()
        }
    }
}
